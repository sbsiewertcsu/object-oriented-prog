// imageproc.cpp : Defines the entry point for the console application.
//
// This example code uses all 1 Dimensional arrays for the images, so please
// convert this to use 2 Dimensional image arrays for more intuitive debug and
// modification of the buffer to annotate images in X,Y coordinates where img[0][0] is
// the top left corner of the image and img[399][299] is the lower right corner of a 
// 400 x 300 image.
//
// This example demonstrates simple transformations of the 1-D image from RGB to grayscale,
// to a grayscale negative and cross-hairs marking the center of the image.
// 
// Be sure all of these features likewise work in your 2D version of this code.  For debug, you
// will not only find VS debugger useful, but you will also find Irfanview useful and Hex Editor Neo.
// Installs for both have been uploaded to Blackboard so you can view the PPM and PGM images and so you
// can look at the binary files a HEX and compare them.
//
// Furthermore, extend the code to creat a color negative of the PPM file and re-output it and likewise
// create a cross-hair annotated version of the PPM and output it too.  Your code should use 2D arrays for
// all image buffers.
//

#include "stdafx.h"

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

typedef struct 
{
	unsigned char Red;
	unsigned char Green;
	unsigned char Blue;
} rgb_pixel_t;

// Basic file read and write functions for PPM and PGM format files
//
#define PPM_TEST_FILE_HEADER_SIZE (37)
#define IMAGE_HEIGHT (300)
#define IMAGE_WIDTH (400)
#define IMAGE_SIZE (IMAGE_HEIGHT * IMAGE_WIDTH)
#define RGB_PIXEL_SIZE (3)
#define PIXEL_SATURATION (255)

static char pgm_header[]="P5\n# CSE A215 Example PGM for C++\n400 300\n255";
static char ppm_header[]="P6\n# CSE A215 Example PPM for C++\n400 300\n255";
static char compare_ppm_header[]="P6\n# Created by IrfanView\n400 300\n255";

static void input_ppm(char *img_buffer, int size)
{
	ifstream ppmFile;
	char ppm_header[PPM_TEST_FILE_HEADER_SIZE+1]; // add one for null termination

	ppmFile.open("C:/temp/Cactus-120kpixel.ppm", ios::in | ios::binary);
	ppm_header[PPM_TEST_FILE_HEADER_SIZE]='\0'; // null termination initialization

	if (ppmFile.fail())
	{
		cerr << "C:/Cactus-120kpixel.ppm file failed to open.\n";
		exit(-1);
	}
	else
	{
		ppmFile.read(ppm_header, PPM_TEST_FILE_HEADER_SIZE);
		cout << ppm_header << "\n";
		
		// Now read in the binary data in RGB order for image size into
		// 1D image array of RGB pixels
		ppmFile.read((char *)img_buffer, size);
	}

	ppmFile.close();
}

static void output_pgm(char *img_buffer, int size, char *filename)
{
    ofstream pgmFile;
   
    pgmFile.open(filename, ios::out | ios::binary);

	// Write out the PGM P5 ASCII header
	//
	pgmFile.write(pgm_header, strlen(pgm_header));

	// Write out the binary image data
    pgmFile.write((char *)img_buffer, size);

    cout << "\nwrote " << size << " bytes to a215-graymap.pgm\n";

    pgmFile.close();   
}


static void output_ppm(char *img_buffer, int size, char *filename)
{
    ofstream ppmFile;
   
    ppmFile.open(filename, ios::out | ios::binary);

	// Write out the PPM P6 ASCII header
	//
	ppmFile.write(ppm_header, strlen(ppm_header));

	// Write out the binary image data
    ppmFile.write((char *)img_buffer, size);

    cout << "\nwrote " << size << " bytes to a215-pixmap.ppm\n";

    ppmFile.close();   
}


// These image buffers are large for the stack, so make them file globals
// which places them in the code data segment.
//
static rgb_pixel_t rgb_image[IMAGE_SIZE]; 
static unsigned char graymap_image[IMAGE_SIZE];
static unsigned char negative_graymap_image[IMAGE_SIZE];
static unsigned char crosshair_graymap_image[IMAGE_SIZE];
static char bigbuffer[IMAGE_SIZE*RGB_PIXEL_SIZE];

int _tmain(int argc, _TCHAR* argv[])
{
	double graymapval;

	cout << "PPM input and PGM Output Template for A215 Array Exercise #4\n";
	cout << "RGB pixel type is structure of size=" << sizeof(rgb_pixel_t) << "\n";
	cout << "RGB image of size=" << sizeof(rgb_image) << ", " << IMAGE_SIZE << " RGB pixels\n";
	cout << "Big buffer size=" << sizeof(bigbuffer) << ", " << sizeof(bigbuffer) << "\n";

	// Simple test to read in PPM and write it write back out with new header with
	// no structure for the bytes in each pixel
	input_ppm(bigbuffer, sizeof(bigbuffer));
	output_ppm(bigbuffer, sizeof(bigbuffer), "C:/temp/a215-pixmap.ppm");

	// Read in the PPM format RGB color image file to 1D array with RGB structure
	input_ppm((char *)rgb_image, sizeof(rgb_image));
	
	// Write out the PPM format pixmap image from 1D array to file with RGB structure
	output_ppm((char *)rgb_image, sizeof(rgb_image), "C:/temp/a215-pixmap-rgb.ppm");


	// Convert the PPM from RGB to single-value pixels in a graymap
	for(int pixel_idx = 0; pixel_idx < IMAGE_SIZE; pixel_idx++)
	{
		// computer the graymap value
		graymapval = 0.3*(rgb_image[pixel_idx].Red) + 
			         0.59*(rgb_image[pixel_idx].Green) + 
					 0.11*(rgb_image[pixel_idx].Blue);

		// convert from floating point to unsigned in range 0...255
		graymap_image[pixel_idx] = (unsigned char)(((unsigned int)graymapval) % (PIXEL_SATURATION+1));

	}


	// Now that we have a graymap, also write out a negative of this image
	for(int pixel_idx = 0; pixel_idx < IMAGE_SIZE; pixel_idx++)
	{
		negative_graymap_image[pixel_idx] = PIXEL_SATURATION - graymap_image[pixel_idx];
	}

	// Write out the PGM format graymap image from 1D array to file
	output_pgm((char *)graymap_image, sizeof(graymap_image), "C:/temp/a215-graymap.pgm");

	// Write out the NEGATIVE PGM format graymap image from 1D array to file
	output_pgm((char *)negative_graymap_image, sizeof(graymap_image), "C:/temp/a215-neg-graymap.pgm");

	// Make a copy of the graymap image for annotation
	memcpy(crosshair_graymap_image, graymap_image, sizeof(graymap_image));

	// Create cross-hairs - note that this is awkward with the 1-D graymap, so when you convert to 2-D,
	// this should be much simpler.  Note that cross-hairs going through the center of the image on X and Y
	// are just at saturation (white).
	int mark_count=0;

	for(int pixel_idx = 0; pixel_idx < IMAGE_SIZE; pixel_idx++)
	{
		// Set saturation for center of each scanline
		if(((pixel_idx % (IMAGE_WIDTH/2)) == 0) && (!((pixel_idx % IMAGE_WIDTH) == 0)))
			crosshair_graymap_image[pixel_idx] = PIXEL_SATURATION;

		// At center row, set all to saturation
		if((pixel_idx > (IMAGE_WIDTH * (IMAGE_HEIGHT/2))) && (mark_count < IMAGE_WIDTH))
		{
			crosshair_graymap_image[pixel_idx] = PIXEL_SATURATION;  mark_count++;
		}
	}

	// Write out the cross-hair annotated graymap image
	output_pgm((char *)crosshair_graymap_image, sizeof(crosshair_graymap_image), "C:/temp/a215-marked-graymap.pgm");

	return 0;
}

