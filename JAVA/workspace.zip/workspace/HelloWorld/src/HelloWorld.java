
public class HelloWorld {
	
	static int idx=0;

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		for(idx=0; idx < 10; idx++)
		{
			System.out.println("Hello world!");
		}

	}

}
